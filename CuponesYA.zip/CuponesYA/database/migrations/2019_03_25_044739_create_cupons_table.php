<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCuponsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cupon', function (Blueprint $table) {
            $table->increments('cupon_id');
            $table->string('cupon_nombre');
            $table->integer('cupon_categoria');
            $table->integer('cupon_empresa');
            $table->string('cupon_descripcion');
            $table->integer('cupon_valor');
            $table->integer('cupon_cantidad');
            $table->date('cupon_fecha_caducidad');
            $table->string('cupon_imagen');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cupon');
    }
}
