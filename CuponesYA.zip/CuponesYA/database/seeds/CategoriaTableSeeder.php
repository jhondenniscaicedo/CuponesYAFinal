<?php

use Illuminate\Database\Seeder;
use App\Categoria;

class CategoriaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //Se crean las categorias en las cuales se separarán los cupones
    	$categoria = new Categoria();
        $categoria->categoria_nombre= 'Sin categoria';
        $categoria->save();

        $categoria = new Categoria();
        $categoria->categoria_nombre= 'Comida';
        $categoria->save();

        $categoria = new Categoria();
        $categoria->categoria_nombre= 'Instrumentos';
        $categoria->save();

        $categoria = new Categoria();
        $categoria->categoria_nombre= 'Tecnologia';
        $categoria->save();

        $categoria = new Categoria();
        $categoria->categoria_nombre= 'Automotores';
        $categoria->save();

        $categoria = new Categoria();
        $categoria->categoria_nombre= 'Ropa';
        $categoria->save();

        $categoria = new Categoria();
        $categoria->categoria_nombre= 'Celulares';
        $categoria->save();

        $categoria = new Categoria();
        $categoria->categoria_nombre= 'Consolas';
        $categoria->save();

        $categoria = new Categoria();
        $categoria->categoria_nombre= 'Cine';
        $categoria->save();

        $categoria = new Categoria();
        $categoria->categoria_nombre= 'Deporte';
        $categoria->save();
    }
}
