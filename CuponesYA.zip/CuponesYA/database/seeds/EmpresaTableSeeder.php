<?php

use Illuminate\Database\Seeder;
use App\Empresa;

class EmpresaTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //Se crean las empresas asociadas a la aplicación
        $empresa = new Empresa();
        $empresa->empresa_nombre = 'Qbano';
        $empresa->save();

        $empresa = new Empresa();
        $empresa->empresa_nombre = 'Fender';
        $empresa->save();

        $empresa = new Empresa();
        $empresa->empresa_nombre = 'Jumbo';
        $empresa->save();

        $empresa = new Empresa();
        $empresa->empresa_nombre = 'ASUS';
        $empresa->save();

        $empresa = new Empresa();
        $empresa->empresa_nombre = 'Adidas';
        $empresa->save();

        $empresa = new Empresa();
        $empresa->empresa_nombre = 'AKT';
        $empresa->save();

        $empresa = new Empresa();
        $empresa->empresa_nombre = 'Xbox';
        $empresa->save();

        $empresa = new Empresa();
        $empresa->empresa_nombre = 'Mattelsa';
        $empresa->save();

        $empresa = new Empresa();
        $empresa->empresa_nombre = 'Royal Films';
        $empresa->save();

        $empresa = new Empresa();
        $empresa->empresa_nombre = 'Nike';
        $empresa->save();
    }
}
