<?php

use Illuminate\Database\Seeder;
use App\Role;

class RoleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	//Se crean los roles que tendrá la aplicación
        $role = new Role();
        $role->name = 'publicista';
        $role->save();

        $role = new Role();
        $role->name = 'registrado';
        $role->save();
    }
}
