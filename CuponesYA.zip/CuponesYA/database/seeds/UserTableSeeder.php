<?php

use Illuminate\Database\Seeder;
use App\User;
use App\Role;

class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	//Se crean instancias de los roles existentes
        $role_publicista = Role::where('name','publicista')->first();
        $role_registrado = Role::where('name','registrado')->first();

        //Se crean usuarios y se les asignan los roles correspondientes
        $user = new User();
        $user->name = 'Publicista';
        $user->username = 'publicista';
        $user->email = 'publicista@gmail.com';
        $user->password = bcrypt('123456789');
        $user->save();
        $user->roles()->attach($role_publicista);

        $user = new User();
        $user->name = 'Eduardo Nicolás Pérez Paredes';
        $user->username = 'eduardoperez';
        $user->email = 'eduardonicolas0916@gmail.com';
        $user->password = bcrypt('123456789');
        $user->save();
        $user->roles()->attach($role_registrado);

        $user = new User();
        $user->name = 'Jhon Dennis Caicedo Diaz';
        $user->username = 'jhond';
        $user->email = 'jhond@gmail.com';
        $user->password = bcrypt('123456789');
        $user->save();
        $user->roles()->attach($role_registrado);

        $user = new User();
        $user->name = 'Luisa María Gómez Galíndez';
        $user->username = 'luisagomez';
        $user->email = 'luisagomez@gmail.com';
        $user->password = bcrypt('123456789');
        $user->save();
        $user->roles()->attach($role_registrado);        
    }
}
