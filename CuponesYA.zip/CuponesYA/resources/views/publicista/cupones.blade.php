@extends('layouts.app')

@section('content')
	
	<div class="container">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<h3>Listado de Cupones</h3>
			@include('publicista.search')
			<a href="cupones/crear"><button class="btn btn-success">Crear Cupón</button></a>
		</div>
	</div>

	<div class="container">
		<div class="col-lg-12 col-sm-12 col-xs-12">
			<div class="table-responsive">
				<table class="table table-striped table-bordered table-condensed table-hover columnaCupones">
					@foreach ($cupones as $cup)
					<tr>
						<td><img src="{{asset($cup->cupon_imagen)}}" height="200" width="350"></td>
						<td>
							<p>Cupon: {{$cup-> cupon_nombre}}</p>
							<p>Código: {{$cup-> cupon_id}}</p>
							<p>Categoría: {{$cup-> categoria_nombre}}</p>
							<p>Empresa: {{$cup-> empresa_nombre}}</p>
							<p>Descripción: {{$cup-> cupon_descripcion}}</p>
							<p>Valor: {{$cup-> cupon_valor}}</p>
							<p>Existencias: {{$cup-> cupon_cantidad}}</p>
							<p>Válido hasta: {{$cup-> cupon_fecha_caducidad}}</p>
						</td>
						@if($cup->cupon_cantidad == 0)
							<td>
								<p>Cupón agotado</p>
							</td>
						@else
							<td>
								<a href="/cupones/{{ $cup->cupon_id }}/editar"><button class="btn btn-info btn-block block">Editar</button></a>
							</td>
							<td>
								<a href="/cupones/{{ $cup->cupon_id }}/eliminar"><button class="btn btn-info btn-danger block">Eliminar</button></a>
							</td>
						@endif
					</tr>
					@endforeach
				</table>
			</div>
			{{$cupones->render()}}
		</div>	
	</div>
@endsection

