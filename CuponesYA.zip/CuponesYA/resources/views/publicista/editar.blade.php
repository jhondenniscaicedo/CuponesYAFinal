@extends('layouts.app')

@section('content')
<head>
    <title>Editar Cupón</title>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
    <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.js"></script>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Editar Cupón: {{ $cupon->cupon_nombre }}</div>

                    <div class="card-body">
                        {!!Form::model($cupon, ['method'=>'PATCH', 'action' => ['CuponController@update', $cupon->cupon_id]])!!}
                        {{Form::token()}}
                            <div class="form-group row">
                                <label for="cupon_nombre" class="col-md-4 col-form-label text-md-right">{{ __('Nombre') }}</label>

                                <div class="col-md-6">
                                    <input id="cupon_nombre" type="text" class="form-control{{ $errors->has('cupon_nombre') ? ' is-invalid' : '' }}" name="cupon_nombre" value="{{ $cupon->cupon_nombre }}" required autofocus>

                                    @if ($errors->has('cupon_nombre'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('cupon_nombre') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cupon_categoria" class="col-md-4 col-form-label text-md-right">{{ __('Categoría') }}</label>

                                <div class="col-md-6">
                                     <select class="form-control" name="cupon_categoria">
                                        @foreach($categorias as $categoria)
                                            <option value="{{$categoria->categoria_id}}">{{$categoria->categoria_nombre}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cupon_empresa" class="col-md-4 col-form-label text-md-right">{{ __('Empresa') }}</label>

                                <div class="col-md-6">
                                    <select class="form-control" name="cupon_empresa">
                                        @foreach($empresas as $empresa)
                                            <option value="{{$empresa->empresa_nit}}">{{$empresa->empresa_nombre}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cupon_descripcion" class="col-md-4 col-form-label text-md-right">{{ __('Descripción') }}</label>

                                <div class="col-md-6">
                                    <input id="cupon_descripcion" type="text" class="form-control{{ $errors->has('cupon_descripcion') ? ' is-invalid' : '' }}" name="cupon_descripcion" value="{{ $cupon->cupon_descripcion }}" required autofocus>

                                    @if ($errors->has('cupon_descripcion'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('cupon_descripcion') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cupon_valor" class="col-md-4 col-form-label text-md-right">{{ __('Valor') }}</label>

                                <div class="col-md-6">
                                    <input id="cupon_valor" type="text" class="form-control{{ $errors->has('cupon_valor') ? ' is-invalid' : '' }}" name="cupon_valor" value="{{ $cupon->cupon_valor }}" required autofocus>

                                    @if ($errors->has('cupon_valor'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('cupon_valor') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cupon_cantidad" class="col-md-4 col-form-label text-md-right">{{ __('Cantidad') }}</label>

                                <div class="col-md-6">
                                    <input id="cupon_cantidad" type="text" class="form-control{{ $errors->has('cupon_cantidad') ? ' is-invalid' : '' }}" name="cupon_cantidad" value="{{ $cupon->cupon_cantidad }}" required autofocus>

                                    @if ($errors->has('cupon_cantidad'))
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $errors->first('cupon_cantidad') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cupon_fecha_caducidad" class="col-md-4 col-form-label text-md-right">{{ __('Fecha de Caducidad') }}</label>
                                    <div class="col-md-6">
                                        <input id="cupon_fecha_caducidad" type="date" min="<?php echo date("Y-m-d");?>" value="<?php echo date("Y-m-d");?>" class="form-control{{ $errors->has('cupon_fecha_caducidad') ? ' is-invalid' : '' }}" name="cupon_fecha_caducidad" value="{{ $cupon->cupon_fecha_caducidad }}" required autofocus>
                                    </div>
                            </div>

                            <div class="form-group row">
                                <label for="cupon_imagen" class="col-md-4 col-form-label text-md-right">{{ __('Imágen') }}</label>

                                <div class="col-md-6">
                                    <input id="cupon_imagen" type="file" class="form-control{{ $errors->has('cupon_imagen') ? ' is-invalid' : '' }}" name="cupon_imagen" value="{{ $cupon->cupon_imagen }}" enctype=”multipart/form-data” required autofocus>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button class="btn btn-primary" type="submit">Guardar Cambios</button>
                                    <button class="btn btn-danger" type="reset">Cancelar</button>
                                </div>
                            </div>

                        {!!Form::close()!!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

@endsection