@extends('layouts.app')

@section('content')

	<div class="container">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<h3>Listado de Cupones</h3>
			@include('invitado.search')
		</div>
	</div>

	<div class="container">
		<div class="col-lg-12 col-sm-12 col-xs-12">
			<div class="table-responsive">
				<table class="table table-striped table-bordered table-condensed table-hover">
					@foreach ($cupones as $cup)
					<tr>
						<td><img src="{{asset($cup->cupon_imagen)}}" height="200" width="350"></td>
						<td>
							<p>Cupon: {{$cup-> cupon_nombre}}</p>
							<p>Categoría: {{$cup-> categoria_nombre}}</p>
							<p>Empresa: {{$cup-> empresa_nombre}}</p>
							<p>Descripción: {{$cup-> cupon_descripcion}}.</p>
							<p>Valor: {{$cup-> cupon_valor}}</p>	
							<p>Válido hasta: {{$cup-> cupon_fecha_caducidad}}</p>
						</td>
						@if($cup->cupon_cantidad == 0)
							<td>
								<p>Cupón agotado</p>
							</td>
						@else
							<td>
								<a href="/cupones/{{ $cup->cupon_id }}/comprar"><button class="btn btn-info btn-block">Comprar</button></a>
							</td>
						@endif
					</tr>
					@endforeach
				</table>
			</div>
			{{$cupones->render()}}
		</div>	
	</div>
@endsection