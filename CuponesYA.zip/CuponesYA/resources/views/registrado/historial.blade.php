@extends('layouts.app')

@section('content')
	
	<div class="container">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<h3>Historial de Cupones</h3>
			@include('registrado.historialSearch')
		</div>
	</div>

	<div class="container">
		<div class="col-lg-12 col-sm-12 col-xs-12">
			<div class="table-responsive">
				<table class="table table-striped table-bordered table-condensed table-hover">
					@foreach ($cupones as $cup)
					<tr>
						<td><img src="{{asset($cup->cupon_imagen)}}"></td>
						<td>
							<p>Cupon: {{$cup-> cupon_nombre}}</p>
							<p>Categoría: {{$cup-> categoria_nombre}}</p>
							<p>Empresa: {{$cup-> empresa_nombre}}</p>
							<p>Descripción: {{$cup-> cupon_descripcion}}.</p>
							<p>Valor: {{$cup-> cupon_valor}}</p>	
							<p>Válido hasta: {{$cup-> cupon_fecha_caducidad}}</p>
						</td>
						<td>
							<a href="{{action('HistorialController@redimirCupon',[$cup->cupon_id ])}}"><button class="btn btn-info btn-block">Descargar</button></a>
						</td>
					</tr>
					@endforeach
				</table>
			</div>
			{{$cupones->render()}}
		</div>	
	</div>
@endsection
