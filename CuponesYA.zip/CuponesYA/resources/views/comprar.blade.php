@extends('layouts.app')

@section('content')
<head>
    <title>Comprar Cupón</title>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
    <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.js"></script>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Comprar Cupón</div>
                    <div class="card-body">
                        {!!Form::open(array('url'=>'comprar','method'=>'POST','autocomplete'=>'off','files'=>true))!!}
                        {{Form::token()}}
                            <div class="form-group row" hidden>
                                <label for="cupon" class="col-md-4 col-form-label text-md-right">{{ __('Cupon') }}</label>
                                <div class="col-md-6">
                                    <input id="cupon" type="text" class="form-control{{ $errors->has('cupon') ? ' is-invalid' : '' }}" name="cupon" value="{{ $cupon->cupon_id }}" required autofocus>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Nombre') }}</label>

                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ old('name') }}" required autofocus>
                                </div>
                            </div>

                            <div class="form-group row">
	                            <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('Correo Electrónico') }}</label>

	                            <div class="col-md-6">
	                                <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" required>
	                            </div>
	                        </div>

                            <div class="form-group row">
                                <label for="telefono" class="col-md-4 col-form-label text-md-right">{{ __('Teléfono') }}</label>

                                <div class="col-md-6">
                                    <input id="telefono" type="text" class="form-control{{ $errors->has('telefono') ? ' is-invalid' : '' }}" name="telefono" value="{{ old('telefono') }}" required autofocus>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="tipo_documento" class="col-md-4 col-form-label text-md-right">{{ __('Tipo de Documento') }}</label>

                                <div class="col-md-6">
                                    <select name="tipo_documento" class="form-control" required autofocus="">
										<option value="1">Cédula Ciudadanía</option>
										<option value="2">Cédula Extranjería</option>										
									</select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="numero_documento" class="col-md-4 col-form-label text-md-right">{{ __('Número de Documento') }}</label>

                                <div class="col-md-6">
                                    <input id="numero_documento" type="text" class="form-control{{ $errors->has('numero_documento') ? ' is-invalid' : '' }}" name="numero_documento" value="{{ old('numero_documento') }}" required autofocus>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button class="btn btn-primary" type="submit">Realizar Compra</button>
                                    <button class="btn btn-danger" type="reset">Cancelar</button>
                                </div>
                            </div>

                        {!!Form::close()!!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

@endsection