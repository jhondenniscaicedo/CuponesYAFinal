<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CuponFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'cupon_nombre' => 'required|string',
            'cupon_categoria' => 'required|integer',
            'cupon_empresa' => 'required|integer',
            'cupon_descripcion' => 'required|string',
            'cupon_valor' => 'required|integer',
            'cupon_cantidad' => 'required|integer',
            'cupon_fecha_caducidad' => 'required|date',
            'cupon_imagen' => 'required|file|mimes:png,gif,jpeg,pdf|max:4096',
        ];
    }
}
