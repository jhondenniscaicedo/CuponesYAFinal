<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use App\Cupon;
use App\Historial;
use Image;
use DB;

class HistorialController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    {
        if(\Auth::check())
        {
            $request->user()->authorizeRoles(['registrado']);
            $query = trim($request->get('searchText'));
            $cupones = DB::table('historial')
            ->where('cupon_nombre','LIKE','%'.$query.'%')
            ->join('cupon','historial.historial_cupon_id','=','cupon.cupon_id')
            ->join('empresa','cupon.cupon_empresa','=','empresa.empresa_nit')
            ->join('categoria','cupon.cupon_categoria','=','categoria.categoria_id')
            ->orderBy('cupon.cupon_nombre','asc')
            ->paginate(5);
            return view('registrado.historial',["cupones"=>$cupones,"searchText"=>$query]);
        }
        else
        {
            return "No autorizado"; //Implementar redirección a página de error
        }
    }

    //Redimir cupon
    public function redimirCupon($id)
    {
        $cupon = Cupon::find($id);
        $ruta = $cupon->cupon_imagen;
        return response()->download($ruta);
    }
}
