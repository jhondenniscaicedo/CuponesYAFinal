<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests\ComprarFormRequest;
use Illuminate\Support\Facades\Auth;
use App\Cupon;
use App\Historial;
use DB;

class ComprarController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
            
    }

    public function comprar($id)
    {
    	$cupon = Cupon::find($id);
    	return view('comprar',compact('cupon'));
    }

    public function store(ComprarFormRequest $request)
    {
        $id = $request->cupon;
        if(\Auth::check())
        {
            if($request->user()->hasRole('registrado'))
            {
                $user_id = Auth::id();
                $cupon = Cupon::find($id);
                $cupon->cupon_cantidad = $cupon->cupon_cantidad - 1;
                $historial = new Historial;
                $historial->historial_user_id = $user_id;
                $historial->historial_cupon_id = $id;
                $cupon->save();
                $historial->save();
            	return Redirect::to('/historial');
            }
        }
        else
        {
            $cupon = Cupon::find($id);
            $ruta = $cupon->cupon_imagen;
            $cupon->cupon_cantidad = $cupon->cupon_cantidad - 1;
            $cupon->save();
        	return Redirect::to('/');
        }
    }
}