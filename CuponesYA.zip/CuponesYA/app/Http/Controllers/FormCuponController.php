<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests;
use App\Empresa;
use App\Categoria;

class FormCuponController extends Controller
{
    function index()
    {
        $empresas = Empresa::all();
        $categorias = Categoria::all();
        return view('publicista.crear', compact('empresas','categorias'));
    }
}
