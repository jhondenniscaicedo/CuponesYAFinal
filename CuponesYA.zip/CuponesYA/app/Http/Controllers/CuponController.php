<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests\CuponFormRequest;
use App\Cupon;
use App\Empresa;
use App\Categoria;
use Image;
use DB;

class CuponController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    {
    	if(\Auth::check())
        {
		    $query = trim($request->get('searchText'));
            $cupones = DB::table('cupon')
            ->where('cupon_nombre','LIKE','%'.$query.'%')
            ->join('empresa','cupon.cupon_empresa','=','empresa.empresa_nit')
            ->join('categoria','cupon.cupon_categoria','=','categoria.categoria_id')
            ->orderBy('cupon.cupon_nombre','asc')
            ->paginate(5);
            if($request->user()->hasRole('publicista'))
            {
                return view('publicista.cupones',["cupones"=>$cupones,"searchText"=>$query]);
            }
            if($request->user()->hasRole('registrado'))
            {
                return view('registrado.cupones',["cupones"=>$cupones,"searchText"=>$query]);
            }
		} 
		else 
		{
		    $query = trim($request->get('searchText'));
            $cupones = DB::table('cupon')         
            ->where('cupon_nombre','LIKE','%'.$query.'%')   
            ->join('empresa','cupon.cupon_empresa','=','empresa.empresa_nit')
            ->join('categoria','cupon.cupon_categoria','=','categoria.categoria_id')
            ->orderBy('cupon.cupon_nombre','asc')
            ->paginate(5);
            return view('invitado.cupones',["cupones"=>$cupones,"searchText"=>$query]);
		}
	}

    //Almancena un cupón en la BD
    public function store(CuponFormRequest $request)
    {
        $cupon = new Cupon;
        $cupon->cupon_nombre = $request->get('cupon_nombre');
        $cupon->cupon_categoria = $request->get('cupon_categoria');
        $cupon->cupon_empresa = $request->get('cupon_empresa');
        $cupon->cupon_descripcion = $request->get('cupon_descripcion');
        $cupon->cupon_valor = $request->get('cupon_valor');
        $cupon->cupon_cantidad = $request->get('cupon_cantidad');
        $cupon->cupon_fecha_caducidad = $request->get('cupon_fecha_caducidad');
        //Guardar imágen
        $ruta = public_path().'/image';
        $file = $request->file('cupon_imagen');
        $nombre = $file->getClientOriginalName();
        $nombreTmp = $this->random_string() . '.' . $file->getClientOriginalExtension();
        $cupon->cupon_imagen = $request->file('cupon_imagen')->store('image');
        $cupon->save();
        return Redirect::to('/cupones');
    }

    //Redirige a la vista para editar cupones
    public function edit($id)
    {
        $cupon = Cupon::find($id);
        $empresas = Empresa::all();
        $categorias = Categoria::all();
        return view('publicista.editar',compact('cupon','empresas','categorias'));
    }

    //Edita la información de un cupón ya existente en la BD
    public function update(CuponFormRequest $request, $id)
    {
        $cupon = Cupon::findOrFail($id);
        $cupon->cupon_nombre = $request->get('cupon_nombre');
        $cupon->cupon_categoria = $request->get('cupon_categoria');
        $cupon->cupon_empresa = $request->get('cupon_empresa');
        $cupon->cupon_descripcion = $request->get('cupon_descripcion');
        $cupon->cupon_valor = $request->get('cupon_valor');
        $cupon->cupon_cantidad = $request->get('cupon_cantidad');
        $cupon->cupon_fecha_caducidad = $request->get('cupon_fecha_caducidad');
        //Guardar imágen
        $ruta = public_path().'/image';
        $file = $request->file('cupon_imagen');
        $nombre = $file->getClientOriginalName();
        $nombreTmp = $this->random_string() . '.' . $file->getClientOriginalExtension();
        $cupon->cupon_imagen = $request->file('cupon_imagen')->store('image');
        $cupon->save();
        return Redirect::to('/cupones');
    }

    public function destroy($id)
    {
        $cupon = Cupon::find($id);
        $ruta = $cupon->cupon_imagen;
        //return "$ruta";
        \File::delete(public_path($ruta));
        $cupon->delete();
        return Redirect::to('/cupones');
    }

    protected function random_string()
    {
        $key = '';
        $keys = array_merge( range('a','z'), range(0,9) );
        for($i=0; $i<10; $i++)
        {
            $key .= $keys[array_rand($keys)];
        }
        return $key;
    }
}
