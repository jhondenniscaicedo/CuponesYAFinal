<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cupon extends Model
{
    protected $table = 'cupon';

    protected $primaryKey = 'cupon_id';

    protected $fillable = [
    	'cupon_nombre',
    	'cupon_categoria',
    	'cupon_empresa',
    	'cupon_descripcion',
    	'cupon_valor',
    	'cupon_cantidad',
    	'cupon_fecha_caducidad',
    	'cupon_imagen',
    ];
}
