<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return Redirect::to('/cupones');
});

Auth::routes();

Route::post('/cupones', 'CuponController@store')->name('cupones');

Route::get('/cupones', 'CuponController@index')->name('cupones');

Route::get('cupones/crear', ['as' => 'crear', 'uses' => 'FormCuponController@index']);

Route::get('/historial', 'HistorialController@index')->name('historial');

Route::get('/historial/{id}/redimir', ['as' => 'redimir', 'uses' => 'HistorialController@redimirCupon']);

Route::get('/cupones/{id}/editar', ['as' => 'editar', 'uses' => 'CuponController@edit']);

Route::patch('/cupones/{id}/editar', ['as' => 'editar', 'uses' => 'CuponController@update']);

Route::get('/cupones/{id}/eliminar', ['as' => 'eliminar', 'uses' => 'CuponController@destroy']);

Route::get('/cupones/{id}/comprar', ['as' => 'comprar', 'uses' => 'ComprarController@comprar']);

Route::post('/cupones/{id}/comprar', ['as' => 'comprar', 'uses' => 'ComprarController@store']);

Route::post('/comprar', ['as' => 'comprar', 'uses' => 'ComprarController@store']);