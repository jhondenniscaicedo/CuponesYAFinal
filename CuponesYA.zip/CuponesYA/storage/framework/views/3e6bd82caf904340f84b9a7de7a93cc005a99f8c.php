<?php $__env->startSection('content'); ?>
	
	<div class="container">
		<div class="top-right links">			
            <a href="/"><i class="fa fa-circle-o"></i>Página de Inicio</a>
        </div>
	</div>

	<div class="container">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<h3>Medio de pago</h3>
		</div>
	</div>
	<div class="container">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<!--<label>Tarjeta de crédito</label><br>-->
			<select name ="tarjeta">
				<option value="1">Tarjeta de crédito</option>
				<option value="2">Tarjeta débito</option>
				<option value="3">PayPal</option>
				<option value="4">PayU</option>

			</select>
			<input type="text" name="tarjeta">
		</div>
	</div>

    <div class="card-body">
	    <?php echo Form::open(array('url'=>'cupones','method'=>'POST','autocomplete'=>'off','files'=>true)); ?>

	    <?php echo e(Form::token()); ?>

	        <div class="form-group row mb-0">
	            <div class="col-md-6 offset-md-4">
	                <a href="<?php echo e(action('pagoCuponController@store',[$cupon->cupon_id ])); ?>"><button class="btn btn-primary" type="submit">Aceptar</button>
	              </a>
	            </div>
	        </div>

	    <?php echo Form::close(); ?>

	</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\roles\resources\views/mostrar.blade.php */ ?>