<?php $__env->startSection('content'); ?>
<div class="flex-center position-ref full-height">
    INICIO DE INVITADOS
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\roles\resources\views/home.blade.php */ ?>