<?php $__env->startSection('content'); ?>
<head>
    <title>Crear Cupón</title>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
    <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.js"></script>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Nuevo Cupón</div>

                    <div class="card-body">
                        <?php echo Form::open(array('url'=>'cupones','method'=>'POST','autocomplete'=>'off','files'=>true)); ?>

                        <?php echo e(Form::token()); ?>

                            <div class="form-group row">
                                <label for="cupon_nombre" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>

                                <div class="col-md-6">
                                    <input id="cupon_nombre" type="text" class="form-control<?php echo e($errors->has('cupon_nombre') ? ' is-invalid' : ''); ?>" name="cupon_nombre" value="<?php echo e(old('cupon_nombre')); ?>" required autofocus>

                                    <?php if($errors->has('cupon_nombre')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('cupon_nombre')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cupon_categoria" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Categoría')); ?></label>

                                <div class="col-md-6">
                                     <select class="form-control" name="cupon_categoria">
                                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($categoria->categoria_id); ?>"><?php echo e($categoria->categoria_nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cupon_empresa" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Empresa')); ?></label>

                                <div class="col-md-6">
                                    <select class="form-control" name="cupon_empresa">
                                        <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($empresa->empresa_nit); ?>"><?php echo e($empresa->empresa_nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cupon_descripcion" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Descripción')); ?></label>

                                <div class="col-md-6">
                                    <input id="cupon_descripcion" type="text" class="form-control<?php echo e($errors->has('cupon_descripcion') ? ' is-invalid' : ''); ?>" name="cupon_descripcion" value="<?php echo e(old('cupon_descripcion')); ?>" required autofocus>

                                    <?php if($errors->has('cupon_descripcion')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('cupon_descripcion')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cupon_valor" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Valor')); ?></label>

                                <div class="col-md-6">
                                    <input id="cupon_valor" type="text" class="form-control<?php echo e($errors->has('cupon_valor') ? ' is-invalid' : ''); ?>" name="cupon_valor" value="<?php echo e(old('cupon_valor')); ?>" required autofocus>

                                    <?php if($errors->has('cupon_valor')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('cupon_valor')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cupon_cantidad" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Cantidad')); ?></label>

                                <div class="col-md-6">
                                    <input id="cupon_cantidad" type="text" class="form-control<?php echo e($errors->has('cupon_cantidad') ? ' is-invalid' : ''); ?>" name="cupon_cantidad" value="<?php echo e(old('cupon_cantidad')); ?>" required autofocus>

                                    <?php if($errors->has('cupon_cantidad')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('cupon_cantidad')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cupon_fecha_caducidad" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fecha de Caducidad')); ?></label>
                                    <div class="col-md-6">
                                        <input id="cupon_fecha_caducidad" type="date" min="<?php echo date("Y-m-d");?>" value="<?php echo date("Y-m-d");?>" class="form-control<?php echo e($errors->has('cupon_fecha_caducidad') ? ' is-invalid' : ''); ?>" name="cupon_fecha_caducidad" value="<?php echo e(old('cupon_fecha_caducidad')); ?>" required autofocus>
                                    </div>
                            </div>

                            <div class="form-group row">
                                <label for="cupon_imagen" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Imágen')); ?></label>

                                <div class="col-md-6">
                                    <input id="cupon_imagen" type="file" class="form-control<?php echo e($errors->has('cupon_imagen') ? ' is-invalid' : ''); ?>" name="cupon_imagen" value="<?php echo e(old('cupon_imagen')); ?>" enctype=”multipart/form-data” required autofocus>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button class="btn btn-primary" type="submit">Guardar Cupón</button>
                                    <button class="btn btn-danger" type="reset">Cancelar</button>
                                </div>
                            </div>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\roles\resources\views/publicista/crear.blade.php */ ?>