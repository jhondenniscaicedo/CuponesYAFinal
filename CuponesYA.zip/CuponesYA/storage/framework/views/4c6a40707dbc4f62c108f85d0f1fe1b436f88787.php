<?php $__env->startSection('content'); ?>
<head>
    <title>Comprar Cupón</title>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
    <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.6/js/bootstrap.js"></script>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Comprar Cupón</div>
                    <div class="card-body">
                        <?php echo Form::open(array('url'=>'comprar','method'=>'POST','autocomplete'=>'off','files'=>true)); ?>

                        <?php echo e(Form::token()); ?>

                            <div class="form-group row" hidden>
                                <label for="cupon" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Cupon')); ?></label>
                                <div class="col-md-6">
                                    <input id="cupon" type="text" class="form-control<?php echo e($errors->has('cupon') ? ' is-invalid' : ''); ?>" name="cupon" value="<?php echo e($cupon->cupon_id); ?>" required autofocus>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>

                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
                                </div>
                            </div>

                            <div class="form-group row">
	                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Correo Electrónico')); ?></label>

	                            <div class="col-md-6">
	                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>
	                            </div>
	                        </div>

                            <div class="form-group row">
                                <label for="telefono" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Teléfono')); ?></label>

                                <div class="col-md-6">
                                    <input id="telefono" type="text" class="form-control<?php echo e($errors->has('telefono') ? ' is-invalid' : ''); ?>" name="telefono" value="<?php echo e(old('telefono')); ?>" required autofocus>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="tipo_documento" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tipo de Documento')); ?></label>

                                <div class="col-md-6">
                                    <select name="tipo_documento" class="form-control" required autofocus="">
										<option value="1">Cédula Ciudadanía</option>
										<option value="2">Cédula Extranjería</option>										
									</select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="numero_documento" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Número de Documento')); ?></label>

                                <div class="col-md-6">
                                    <input id="numero_documento" type="text" class="form-control<?php echo e($errors->has('numero_documento') ? ' is-invalid' : ''); ?>" name="numero_documento" value="<?php echo e(old('numero_documento')); ?>" required autofocus>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button class="btn btn-primary" type="submit">Realizar Compra</button>
                                    <button class="btn btn-danger" type="reset">Cancelar</button>
                                </div>
                            </div>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\CuponesYA\resources\views/comprar.blade.php */ ?>