<?php $__env->startSection('content'); ?>

	<div class="container">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<h3>Listado de Cupones</h3>
			<?php echo $__env->make('registrado.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</div>
	</div>

	<div class="container">
		<div class="col-lg-12 col-sm-12 col-xs-12">
			<div class="table-responsive">
				<table class="table table-striped table-bordered table-condensed table-hover">
					<a href="/historial"><button class="btn btn-primary">Historial de cupones</button></a>
					<?php $__currentLoopData = $cupones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><img src="<?php echo e(asset($cup->cupon_imagen)); ?>" height="200" width="350"></td>
						<td>
							<p>Cupon: <?php echo e($cup-> cupon_nombre); ?></p>
							<p>Categoría: <?php echo e($cup-> categoria_nombre); ?></p>
							<p>Empresa: <?php echo e($cup-> empresa_nombre); ?></p>
							<p>Descripción: <?php echo e($cup-> cupon_descripcion); ?>.</p>
							<p>Valor: <?php echo e($cup-> cupon_valor); ?></p>	
							<p>Válido hasta: <?php echo e($cup-> cupon_fecha_caducidad); ?></p>						
						</td>
						<?php if($cup->cupon_cantidad == 0): ?>
							<td>
								<p>Cupón agotado</p>
							</td>
						<?php else: ?>
							<td>
								<a href="/cupones/<?php echo e($cup->cupon_id); ?>/comprar"><button class="btn btn-info btn-block">Comprar</button></a>
							</td>
						<?php endif; ?>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</table>
			</div>
			<?php echo e($cupones->render()); ?>

		</div>	
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\CuponesYA\resources\views/registrado/cupones.blade.php */ ?>